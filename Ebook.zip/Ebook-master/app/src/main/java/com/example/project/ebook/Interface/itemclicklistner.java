package com.example.project.ebook.Interface;

import android.view.View;

public interface itemclicklistner {

    Void onClick(View view, int position , boolean isLongClick );
}
