package com.example.project.ebook.Prevalent;

import com.example.project.ebook.Model.Users;

public class Prevalent {
    public static Users onlineuser;

    public static final String phonekey = "Userphone";
    public static final String passwordkey = "Userpassword";
}
